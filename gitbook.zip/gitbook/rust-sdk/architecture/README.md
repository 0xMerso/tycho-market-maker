# Architecture

## System Design

The Tycho Market Maker follows a modular, event-driven architecture optimized for high-frequency trading operations.

```
┌─────────────────┐     ┌─────────────────┐
│   Price Feeds   │────▶│  Market Maker   │
│  (Binance/CL)   │     │   Core Engine   │
└─────────────────┘     └────────┬────────┘
                                 │
                    ┌────────────┼────────────┐
                    ▼            ▼            ▼
            ┌──────────┐  ┌──────────┐  ┌──────────┐
            │  Tycho   │  │  Chain   │  │  Redis   │
            │   API    │  │ Executor │  │ Pub/Sub  │
            └──────────┘  └──────────┘  └──────────┘
                                              │
                                         ┌────▼────┐
                                         │Postgres │
                                         │Monitor  │
                                         └─────────┘
```

## Core Components

### Market Maker Engine
Central orchestrator managing:
- Price discovery
- Opportunity detection
- Execution coordination
- Risk management

Located in `src/shd/maker/impl.rs`

### Price Feed System
Factory-based feed instantiation:
- **Binance WebSocket**: Real-time CEX prices
- **Chainlink Oracle**: Decentralized price validation
- Automatic fallback mechanisms

Implementation: `src/shd/maker/feed.rs`

### Execution Layer
Chain-specific strategies:
- **Mainnet**: Flashbots bundle submission
- **Base**: L2 optimized transactions
- **Unichain**: Native protocol integration

Directory: `src/shd/maker/exec/chain/`

### Event System (Optional)
Redis-powered real-time messaging for monitoring:
- Trade notifications
- Error alerts
- Performance metrics
- System health updates

Files: `src/shd/data/pub.rs`, `src/shd/data/sub.rs`

Note: The market maker runs perfectly without Redis/PostgreSQL. These are only required for:
- Persisting trade history
- Real-time monitoring dashboard
- Connecting the frontend UI

## Data Flow

### 1. Market Discovery
```rust
loop {
    let market_state = tycho_client.get_state().await?;
    let pools = filter_relevant_pools(market_state);
}
```

### 2. Price Analysis
```rust
let cex_price = price_feed.get_price("ETH/USDC").await?;
let pool_price = calculate_pool_price(pool);
let spread = (cex_price - pool_price).abs() / cex_price;
```

### 3. Execution Decision
```rust
if spread > config.min_profit_bps {
    let tx = build_transaction(pool, amount);
    executor.submit(tx).await?;
}
```

### 4. Event Publishing
```rust
redis_pub.publish(TradeEvent {
    pool_id,
    profit,
    gas_used,
    timestamp,
}).await?;
```

## Configuration Management

Dual-layer configuration:

### Static Config (TOML)
Trading parameters, network settings:
```toml
[trading]
polling_interval_ms = 1000
min_profit_bps = 10
```

### Dynamic Config (ENV)
Sensitive data, runtime variables:
```env
PRIVATE_KEY=0x...
TYCHO_API_KEY=...
```

## Fault Tolerance

### Automatic Recovery
- Panic handler with exponential backoff
- Transaction retry logic
- Connection pooling

### Health Monitoring
- Heartbeat system
- Resource tracking
- Performance metrics

## Performance Optimizations

### Concurrent Processing
- Tokio async runtime
- Parallel pool analysis
- Batched database writes

### Memory Management
- Object pooling
- Lazy static initialization
- Efficient serialization

## Security Considerations

### Private Key Management
- Environment-based storage
- Never logged or exposed
- Secure transaction signing

### MEV Protection
- Flashbots integration (mainnet)
- Commit-reveal patterns
- Time-based randomization

## Extension Points

### Custom Price Feeds
Implement `PriceFeedBase` trait:
```rust
#[async_trait]
pub trait PriceFeedBase {
    async fn get_price(&self, pair: &str) -> Result<f64>;
}
```

### Custom Executors
Extend `ChainExecutor` trait for new chains.

### Event Handlers
Subscribe to Redis channels for custom logic.