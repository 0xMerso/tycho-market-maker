# Quickstart

Get the Tycho Market Maker running locally in under 5 minutes.

## Prerequisites

Required:
- Rust 1.75+ (`curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh`)
- Git

Optional (for monitoring/UI):
- Docker & Docker Compose 
- PostgreSQL 15+ (for trade history)
- Redis 7+ (for real-time events)

## Installation

### 1. Clone Repository

```bash
git clone https://github.com/your-org/tycho-market-maker
cd tycho-market-maker
```

### 2. Setup Environment

Copy the example environment file:
```bash
cp config/secrets/.env.example config/secrets/.env.mainnet
```

Edit with your credentials:
```env
PRIVATE_KEY=0x...
TYCHO_API_KEY=your_api_key
BINANCE_WS_URL=wss://stream.binance.com:9443
DATABASE_URL=postgresql://user:pass@localhost/tycho
REDIS_URL=redis://localhost:6379
```

### 3. Database Setup (Optional)

Only needed if you want to:
- Save trade history to database
- Use the monitoring dashboard
- Connect the frontend UI

Initialize the database:
```bash
sh prisma/all-in-one.sh
```

Skip this step for basic market making without persistence.

### 4. Build Project

```bash
cargo build --release --bin maker
cargo build --release --bin monitor
```

## First Run

### Option 1: Docker (Recommended)

```bash
sh ops/dock.sh up
```

This starts:
- Market maker service
- Monitor service
- PostgreSQL database
- Redis instance

View logs:
```bash
sh ops/dock.sh logs
```

### Option 2: Manual

Start services individually:

**Terminal 1 - Market Maker:**
```bash
sh ops/maker.sh mainnet.eth-usdc
```

**Terminal 2 - Monitor:**
```bash
sh ops/monitor.sh
```

## Verify Installation

Check the market maker is running:
```bash
curl http://localhost:8080/health
```

Expected response:
```json
{"status": "healthy", "uptime": 42}
```

View recent trades:
```bash
psql $DATABASE_URL -c "SELECT * FROM trades ORDER BY created_at DESC LIMIT 5;"
```

## Configuration Files

### Market Config
`config/mainnet.eth-usdc.toml`:
```toml
[network]
chain_id = 1
rpc_url = "https://eth-mainnet.g.alchemy.com/v2/YOUR_KEY"

[tokens]
token0 = "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2"  # WETH
token1 = "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"  # USDC

[trading]
min_profit_bps = 10
max_slippage = 0.005
```

### Quick Test

Run a test trade:
```bash
RUST_LOG=debug cargo run --bin maker -- --config config/mainnet.eth-usdc.toml
```

## Frontend UI (Optional)

Monitor your market maker with the web interface:
```bash
git clone https://github.com/fberger-xyz/tycho-tap5-front
cd tycho-tap5-front
npm install
npm run dev
```

The UI connects to your database to display:
- Real-time trade activity
- Profit/loss tracking
- Performance metrics

## Next Steps

- [Architecture Overview](../architecture/README.md) - Understand system design
- [Usage Guide](../usage/README.md) - Advanced configuration
- [Run Locally](../../application/run-locally/README.md) - Production deployment

## Troubleshooting

**Connection refused:**
Ensure PostgreSQL and Redis are running:
```bash
docker-compose up -d postgres redis
```

**Invalid API key:**
Verify your Tycho API key in `.env` file.

**Insufficient balance:**
Check wallet balance for gas and trading tokens.