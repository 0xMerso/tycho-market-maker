# Usage

## Configuration

### Market Maker Configuration

Create a TOML configuration file for your market:

```toml
# config/mainnet.eth-usdc.toml
[network]
chain_id = 1
rpc_url = "https://eth-mainnet.g.alchemy.com/v2/YOUR_KEY"
explorer = "https://etherscan.io"

[tokens]
token0 = "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2"  # WETH
token0_symbol = "WETH"
token0_decimals = 18

token1 = "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"  # USDC  
token1_symbol = "USDC"
token1_decimals = 6

[trading]
polling_interval_ms = 1000
min_profit_bps = 10
max_slippage = 0.005
max_gas_price_gwei = 100

[feed]
type = "binance"  # or "chainlink"
pair = "ETHUSDC"
```

### Environment Variables

Set sensitive data in `.env` files:

```bash
# config/secrets/.env.mainnet
PRIVATE_KEY=0x...
TYCHO_API_KEY=your_tycho_api_key
TYCHO_API_URL=https://api.tycho.com

# Database
DATABASE_URL=postgresql://user:pass@localhost:5432/tycho
REDIS_URL=redis://localhost:6379

# Optional
FLASHBOTS_RELAY=https://relay.flashbots.net
BINANCE_WS_URL=wss://stream.binance.com:9443
```

## Running the Market Maker

### Basic Operation

Start with default configuration:
```bash
cargo run --bin maker
```

### Specific Market

Run with custom config:
```bash
sh ops/maker.sh mainnet.eth-usdc
```

This script:
1. Loads environment from `config/secrets/.env.mainnet`
2. Applies config from `config/mainnet.eth-usdc.toml`
3. Starts market maker with auto-restart

### Debug Mode

Enable detailed logging:
```bash
RUST_LOG=debug cargo run --bin maker -- --config config/mainnet.eth-usdc.toml
```

Log levels:
- `error`: Critical issues only
- `warn`: Important warnings
- `info`: General information
- `debug`: Detailed execution flow
- `trace`: Maximum verbosity

### Monitoring

Start the monitor service:
```bash
cargo run --bin monitor
```

Monitor features:
- Redis event subscription
- Trade persistence to PostgreSQL
- Real-time metrics aggregation
- Health check endpoints

## Trading Strategies

### Arbitrage Mode

Capture price differences:
```toml
[trading]
strategy = "arbitrage"
min_profit_bps = 5
max_position_size = 10000  # USDC
```

### Market Making Mode

Provide liquidity:
```toml
[trading]
strategy = "market_maker"
spread_bps = 20
inventory_target = 0.5  # 50% of each asset
rebalance_threshold = 0.1
```

### Custom Parameters

Fine-tune execution:
```toml
[execution]
gas_limit_multiplier = 1.2
priority_fee_percentile = 75
max_retries = 3
retry_delay_ms = 500
```

## Price Feeds

### Binance WebSocket

Real-time CEX prices:
```toml
[feed]
type = "binance"
pair = "ETHUSDC"
reconnect_delay_ms = 1000
```

### Chainlink Oracle

Decentralized pricing:
```toml
[feed]
type = "chainlink"
aggregator = "0x5f4eC3Df9cbd43714FE2740f5E3616155c5b8419"  # ETH/USD
heartbeat_seconds = 3600
```

### Custom Feed

Implement your own:
```rust
use shd::maker::feed::PriceFeedBase;

struct MyCustomFeed;

#[async_trait]
impl PriceFeedBase for MyCustomFeed {
    async fn get_price(&self, pair: &str) -> Result<f64> {
        // Your implementation
    }
}
```

## Chain-Specific Settings

### Ethereum Mainnet

MEV protection enabled:
```toml
[network]
chain_id = 1
use_flashbots = true
flashbots_relay = "https://relay.flashbots.net"
```

### Base L2

Optimized for low fees:
```toml
[network]
chain_id = 8453
rpc_url = "https://base.gateway.tenderly.co"
max_gas_price_gwei = 1
```

### Unichain

Native integration:
```toml
[network]
chain_id = 1301
rpc_url = "https://sepolia.unichain.org"
```

## Performance Tuning

### Connection Pooling

```toml
[database]
max_connections = 10
min_connections = 2
connection_timeout_ms = 5000
```

### Batch Processing

```toml
[performance]
batch_size = 100
flush_interval_ms = 1000
```

## Troubleshooting

### Common Issues

**Rate limiting:**
```toml
[network]
request_delay_ms = 100
max_concurrent_requests = 10
```

**Gas estimation failures:**
```toml
[execution]
gas_limit_override = 500000
```

**Connection drops:**
```toml
[network]
keepalive_interval_ms = 30000
reconnect_attempts = 5
```