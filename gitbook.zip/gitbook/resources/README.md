# Resources

## Links

### Official Resources

**Tycho Protocol**
- [Tycho Documentation](https://docs.tycho.com)
- [Tycho API Reference](https://api.tycho.com/docs)
- [Tycho Dashboard](https://dashboard.tycho.com)
- [GitHub Repository](https://github.com/tycho-protocol)

**Market Maker**
- [Source Code](https://github.com/your-org/tycho-market-maker)
- [Frontend UI](https://github.com/fberger-xyz/tycho-tap5-front)
- [Issue Tracker](https://github.com/your-org/tycho-market-maker/issues)
- [Releases](https://github.com/your-org/tycho-market-maker/releases)

### External Tools

**Development**
- [Rust Book](https://doc.rust-lang.org/book/)
- [Tokio Async Runtime](https://tokio.rs)
- [Alloy Framework](https://github.com/alloy-rs/alloy)
- [SeaORM Documentation](https://www.sea-ql.org/SeaORM/)

**Blockchain**
- [Ethereum RPC Providers](https://ethereumnodes.com)
- [Base Documentation](https://docs.base.org)
- [Unichain Docs](https://docs.unichain.org)
- [Flashbots Documentation](https://docs.flashbots.net)

**Price Feeds**
- [Binance API](https://binance-docs.github.io/apidocs/spot/en/)
- [Chainlink Data Feeds](https://docs.chain.link/data-feeds)

### Community

**Discord Channels**
- `#tycho-general` - General discussion
- `#market-maker` - Market maker specific
- `#dev-support` - Technical help

**Social**
- Twitter: [@TychoProtocol](https://twitter.com/TychoProtocol)
- Telegram: [t.me/tycho_protocol](https://t.me/tycho_protocol)

## Configuration Templates

### Mainnet Template
```toml
[network]
chain_id = 1
rpc_url = "https://eth-mainnet.g.alchemy.com/v2/YOUR_KEY"

[tokens]
token0 = "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2"  # WETH
token1 = "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"  # USDC

[trading]
min_profit_bps = 10
max_slippage = 0.005
```

### Base Template
```toml
[network]
chain_id = 8453
rpc_url = "https://base.gateway.tenderly.co"

[trading]
gas_price_multiplier = 1.1
max_gas_price_gwei = 1
```

## Common Token Addresses

### Ethereum Mainnet
- **WETH**: `0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2`
- **USDC**: `0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48`
- **USDT**: `0xdAC17F958D2ee523a2206206994597C13D831ec7`
- **DAI**: `0x6B175474E89094C44Da98b954EedeAC495271d0F`

### Base
- **WETH**: `0x4200000000000000000000000000000000000006`
- **USDC**: `0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913`
- **DAI**: `0x50c5725949A6F0c72E6C4a641F24049A917DB0Cb`

## Useful Commands

### Quick Diagnostics
```bash
# Check system health
curl http://localhost:8080/health

# View recent trades
psql $DATABASE_URL -c "SELECT * FROM trades ORDER BY created_at DESC LIMIT 10;"

# Monitor Redis events
redis-cli SUBSCRIBE "trades:*"

# Check wallet balance
cast balance $WALLET_ADDRESS --rpc-url $RPC_URL
```

### Performance Testing
```bash
# Load test
ab -n 1000 -c 10 http://localhost:8080/health

# Memory profiling
valgrind --tool=massif ./target/release/maker

# CPU profiling
perf record -g ./target/release/maker
perf report
```

## FAQ

**Q: How much capital do I need to start?**
A: Minimum $10,000 recommended for meaningful arbitrage opportunities.

**Q: What's the expected return?**
A: Varies by market conditions. Typical range: 5-20% APY.

**Q: Can I run multiple instances?**
A: Yes, use different wallets and configurations for each.

**Q: How to reduce gas costs?**
A: Use L2 networks like Base, batch transactions, optimize during low-traffic periods.

**Q: Is MEV protection necessary?**
A: Highly recommended on Ethereum mainnet. Use Flashbots or similar.

## Contributing

### Development Setup
```bash
git clone https://github.com/your-org/tycho-market-maker
cd tycho-market-maker
cargo build
cargo test
```

### Submission Guidelines
1. Fork the repository
2. Create feature branch
3. Write tests for new features
4. Ensure `cargo fmt` and `cargo clippy` pass
5. Submit pull request

### Code Style
- Follow Rust conventions
- Document public APIs
- Keep functions under 50 lines
- Write comprehensive tests

## License

This project is licensed under MIT. See [LICENSE](https://github.com/your-org/tycho-market-maker/blob/main/LICENSE) for details.