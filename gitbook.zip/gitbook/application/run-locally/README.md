# Run Locally

## Prerequisites

Required:
- Network access to blockchain RPCs
- 4GB RAM minimum

Optional (for full monitoring):
- Docker & Docker Compose
- PostgreSQL & Redis (for UI/monitoring)
- 10GB free disk space

## Quick Start with Docker

### 1. Clone and Setup

```bash
git clone https://github.com/your-org/tycho-market-maker
cd tycho-market-maker
cp config/secrets/.env.example config/secrets/.env.mainnet
```

### 2. Configure Environment

Edit `config/secrets/.env.mainnet`:
```env
# Required
PRIVATE_KEY=0x...  # Your wallet private key
TYCHO_API_KEY=...   # Get from Tycho dashboard

# Network
RPC_URL=https://eth-mainnet.g.alchemy.com/v2/YOUR_KEY

# Database (Docker will handle)
DATABASE_URL=postgresql://postgres:postgres@db:5432/tycho
REDIS_URL=redis://redis:6379
```

### 3. Start Services

```bash
sh ops/dock.sh up
```

This launches:
- Market Maker container
- Monitor container  
- PostgreSQL database
- Redis cache

### 4. Verify Operation

Check health:
```bash
curl http://localhost:8080/health
```

View logs:
```bash
sh ops/dock.sh logs maker
sh ops/dock.sh logs monitor
```

## Manual Setup (Without Docker)

### 1. Basic Setup (No Database)

Just build and run:
```bash
cargo build --release
./target/release/maker
```

The market maker will run without persistence or monitoring.

### 2. Full Setup (With Monitoring)

**Install Dependencies:**
```bash
# PostgreSQL
brew install postgresql@15
brew services start postgresql@15
createdb tycho

# Redis
brew install redis
brew services start redis
```

**Database Migration:**
```bash
sh prisma/all-in-one.sh
```

### 3. Build Binaries

```bash
cargo build --release
```

### 4. Run Services

**Terminal 1 - Market Maker:**
```bash
./target/release/maker
```

**Terminal 2 - Monitor:**
```bash
./target/release/monitor
```

## Configuration Examples

### Mainnet ETH/USDC

`config/mainnet.eth-usdc.toml`:
```toml
[network]
chain_id = 1
rpc_url = "${RPC_URL}"  # From .env

[tokens]
token0 = "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2"
token1 = "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"

[trading]
min_profit_bps = 10
polling_interval_ms = 1000
```

Run:
```bash
sh ops/maker.sh mainnet.eth-usdc
```

### Base USDC/DAI

`config/base.usdc-dai.toml`:
```toml
[network]
chain_id = 8453
rpc_url = "https://base.gateway.tenderly.co"

[tokens]
token0 = "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913"  # USDC
token1 = "0x50c5725949A6F0c72E6C4a641F24049A917DB0Cb"  # DAI
```

## Development Mode

### Hot Reload

Use cargo-watch:
```bash
cargo install cargo-watch
cargo watch -x "run --bin maker"
```

### Testing

Run integration tests:
```bash
RUST_LOG=debug cargo test -- --nocapture
```

Test specific config:
```bash
cargo test test_mainnet_config -- --nocapture
```

### Debugging

Enable verbose logging:
```bash
RUST_LOG=shd=trace,maker=debug cargo run --bin maker
```

Use VS Code debugger:
```json
{
  "type": "lldb",
  "request": "launch",
  "name": "Debug Maker",
  "cargo": {
    "args": ["build", "--bin=maker"],
    "filter": {
      "name": "maker",
      "kind": "bin"
    }
  },
  "env": {
    "RUST_LOG": "debug"
  }
}
```

## Monitoring Dashboard

### Web UI (Recommended)

Use the dedicated frontend:
```bash
git clone https://github.com/fberger-xyz/tycho-tap5-front
cd tycho-tap5-front
npm install
npm run dev
```

Access at `http://localhost:3000` to view:
- Live trade feed
- Profit/loss charts
- Gas usage analytics
- Performance metrics

### Grafana Setup (Alternative)

1. Start Grafana:
```bash
docker run -d -p 3000:3000 grafana/grafana
```

2. Add PostgreSQL datasource
3. Import dashboard from `ops/grafana/dashboard.json`

## Production Considerations

### Security

- Use hardware wallet or AWS KMS for private keys
- Implement IP whitelisting for RPC endpoints
- Enable TLS for database connections
- Rotate API keys regularly

### Performance

- Use dedicated RPC nodes
- Increase connection pools:
```toml
[database]
max_connections = 50
```

- Enable connection keepalive:
```toml
[network]
keepalive_interval_ms = 30000
```

### Monitoring

- Set up alerts for failed trades
- Monitor wallet balances
- Track gas price spikes
- Watch for RPC rate limits

## Troubleshooting

### Common Issues

**Database connection failed:**
```bash
psql postgresql://postgres:postgres@localhost:5432/tycho
```

**Redis not responding:**
```bash
redis-cli ping
```

**Insufficient gas:**
Check wallet balance and gas settings.

**API rate limits:**
Reduce polling frequency or upgrade RPC plan.

## Support

- GitHub Issues: Bug reports and features
- Discord: Community support
- Documentation: Updates via PRs