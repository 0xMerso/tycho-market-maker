# Introduction

## Overview

The Tycho Market Maker is a high-performance automated market making system built on top of the Tycho Protocol. It bridges centralized exchange pricing with on-chain liquidity pools, enabling efficient capital deployment across multiple EVM chains.

This market maker transforms complex DeFi liquidity structures into actionable trading opportunities by continuously monitoring price discrepancies between CEX feeds and on-chain pools.

## Key Features

### Multi-Chain Support
- **Ethereum Mainnet** with Flashbots MEV protection
- **Base L2** for cost-efficient operations  
- **Unichain** with native support

### Price Feed Integration
- **Binance** real-time WebSocket feeds
- **Chainlink** decentralized oracle pricing
- Configurable fallback mechanisms

### Execution Strategies
- Chain-specific optimization
- Dynamic gas management
- Slippage protection
- MEV-resistant transaction building

## Architecture Highlights

The system employs a modular architecture with:
- **Automatic recovery** from failures
- **Optional monitoring** via Redis pub/sub
- **Optional storage** using PostgreSQL for trade history
- **Optional UI** via [frontend repository](https://github.com/fberger-xyz/tycho-tap5-front)

The core market maker runs standalone without any database dependencies.

## Use Cases

### Arbitrage Trading
Capture price differences between CEX and DEX markets with sub-second execution.

### Liquidity Provision
Provide balanced liquidity based on CEX market conditions.

### Market Making
Maintain tight spreads on-chain using centralized price references.

## Getting Started

This documentation covers:
1. **Rust SDK** - Core library and implementation details
2. **Application** - Running the market maker locally
3. **Resources** - Additional tools and references

Whether you're looking to:
- Deploy your own market maker instance
- Integrate with existing trading infrastructure  
- Understand the Tycho Protocol ecosystem

This guide provides comprehensive coverage of concepts, configuration, and deployment strategies.

## Prerequisites

Before diving in, ensure familiarity with:
- Rust programming language
- EVM blockchain fundamentals
- DeFi concepts (AMMs, liquidity pools)
- Basic Docker and PostgreSQL knowledge

## Support

For questions and contributions:
- GitHub Issues for bug reports
- Documentation updates via PRs
- Community discussions in Tycho Discord

Ready to start? Head to the [Quickstart](rust-sdk/quickstart/README.md) guide.